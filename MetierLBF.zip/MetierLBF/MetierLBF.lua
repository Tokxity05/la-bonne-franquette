-- Métiers LBF - La Bonne Franquette
-- Partage avec la guilde : nom, classe, métiers, recettes connues, recharges. Rien d'autre.

local PREFIXE, PROTOCOLE = "MetierLBF", "1"
local TAILLE, PAUSE = 220, 1.0
local MAX_RECETTES, MAX_MEMBRES = 1500, 1000
local OR, VERT = "|cffd4af37", "|cff1eff00"
local SITE = "https://tokxity05.github.io/la-bonne-franquette/"

local LIGNES = { couture = 197, tailoring = 197, enchantement = 333, enchanting = 333, alchimie = 171, alchemy = 171, forge = 164, blacksmithing = 164,
	["ingénierie"] = 202, engineering = 202, ["travail du cuir"] = 165, leatherworking = 165, herboristerie = 182, herbalism = 182,
	minage = 186, mining = 186, ["dépeçage"] = 393, skinning = 393, cuisine = 185, cooking = 185, secourisme = 129, ["first aid"] = 129,
	["pêche"] = 356, fishing = 356 }

local function sur(f, ...)
	if type(f) ~= "function" then return nil end
	local r = { pcall(f, ...) }
	if not r[1] then return nil end
	return unpack(r, 2, table.maxn(r))
end
local function lisible(v) return v ~= nil and not sur(issecretvalue, v) end
local function texte(v) if lisible(v) and type(v) == "string" and v ~= "" then return v end end
local function nombre(v) if lisible(v) and type(v) == "number" then return v end end
local function oui(v) return lisible(v) and (v == true or v == 1) end
local function court(nom) return nom and (nom:match("^([^%-]+)") or nom) end
local function moi() return court(texte((sur(UnitName, "player")))) end
local function now() return sur(time) or 0 end
local function enGuilde() return IsInGuild and oui(sur(IsInGuild)) end
local function dire(msg) print(OR .. "Métiers LBF|r : " .. msg) end

local B36 = "0123456789abcdefghijklmnopqrstuvwxyz"
local function b36(n)
	n = math.floor(tonumber(n) or 0)
	if n <= 0 then return "0" end
	local s = ""
	while n > 0 do
		local r = n % 36
		s = B36:sub(r + 1, r + 1) .. s
		n = math.floor(n / 36)
	end
	return s
end
local function d36(s) return tonumber(s or "", 36) end
local function split(s, sep)
	local t, i = {}, 1
	while true do
		local j = string.find(s, sep, i, true)
		if not j then t[#t + 1] = s:sub(i); return t end
		t[#t + 1] = s:sub(i, j - 1)
		i = j + #sep
	end
end
local function compter(t) local n = 0 for _ in pairs(t or {}) do n = n + 1 end return n end

local VERSION = texte((C_AddOns and sur(C_AddOns.GetAddOnMetadata, "MetierLBF", "Version")) or sur(GetAddOnMetadata, "MetierLBF", "Version")) or "1.5.0"

local function plusRecente(a, b)
	local x, y = split(a or "0", "."), split(b or "0", ".")
	for k = 1, math.max(#x, #y) do
		local u, v = tonumber(x[k]) or 0, tonumber(y[k]) or 0
		if u ~= v then return u > v end
	end
	return false
end

local majBouton

---------------------------------------------------------------- données

local function db()
	if type(MetierLBFDB) ~= "table" then MetierLBFDB = {} end
	local d = MetierLBFDB
	d.v = 1
	if type(d.membres) ~= "table" then d.membres = {} end
	return d
end
local function enPause() return db().prive == true end

-- Une version plus récente vue chez un membre : gardée jusqu'à la mise à jour (bouton, bulle, message à chaque connexion)
local function nouvelleVersion()
	local v = db().derniere
	if v and plusRecente(v, VERSION) then return v end
end
local prevenu = false
local function annoncerMaj()
	local v = nouvelleVersion()
	if not v or prevenu then return end
	prevenu = true
	dire(string.format("|cffff8000nouvelle version %s disponible|r (tu as la %s). Télécharge-la sur %s#/addons/metier-lbf puis relance le jeu.", v, VERSION, SITE))
	-- au milieu de l'écran aussi : le bouton peut être rangé dans un sac à boutons
	if RaidNotice_AddMessage and RaidWarningFrame then
		local couleur = (ChatTypeInfo and ChatTypeInfo["RAID_WARNING"]) or { r = 1, g = 0.5, b = 0 }
		sur(RaidNotice_AddMessage, RaidWarningFrame, "Métiers LBF : nouvelle version " .. v .. " disponible, pense à mettre l'addon à jour", couleur)
	end
end
local function verifierVersion(v)
	if not v or not plusRecente(v, VERSION) then return end
	local d = db()
	if not d.derniere or plusRecente(v, d.derniere) then d.derniere = v end
	annoncerMaj()
	if majBouton then majBouton() end
end

local function maFiche()
	local nom = moi()
	if not nom or not enGuilde() then return nil end
	local d = db()
	local m = d.membres[nom]
	if type(m) ~= "table" then m = {}; d.membres[nom] = m end
	if type(m.metiers) ~= "table" then m.metiers = {} end
	if type(m.recharges) ~= "table" then m.recharges = {} end
	local _, classe = sur(UnitClass, "player")
	m.classe = texte(classe) or m.classe
	m.version = VERSION
	d.moi = nom
	return m, nom
end

local function metier(m, ligne)
	local x = m.metiers[ligne]
	if type(x) ~= "table" then x = {}; m.metiers[ligne] = x end
	if type(x.ids) ~= "table" then x.ids = {} end
	return x
end

local function lireRangs()
	local m = maFiche()
	if not m then return end
	local lus = 0
	if GetProfessions and GetProfessionInfo then
		local idx = { sur(GetProfessions) }
		for k = 1, 6 do
			if idx[k] then
				local nom, _, rang, max, _, _, ligne = sur(GetProfessionInfo, idx[k])
				ligne = nombre(ligne) or LIGNES[string.lower(texte(nom) or "")]
				if ligne and nombre(rang) then
					local x = metier(m, ligne)
					x.nom, x.rang, x.max = texte(nom) or x.nom, nombre(rang), nombre(max) or x.max
					lus = lus + 1
				end
			end
		end
	end
	if lus > 0 then return end
	-- ancienne API
	local nb = (C_SkillInfo and sur(C_SkillInfo.GetNumSkillLines)) or sur(GetNumSkillLines) or 0
	for i = 1, nb do
		local nom, entete, rang, max
		if C_SkillInfo and C_SkillInfo.GetSkillLineInfo then
			local s = sur(C_SkillInfo.GetSkillLineInfo, i)
			if type(s) == "table" then nom, entete, rang, max = s.name, s.isHeader, s.rank, s.maxRank end
		else
			local a, b, _, r, _, _, mx = sur(GetSkillLineInfo, i)
			nom, entete, rang, max = a, b, r, mx
		end
		local ligne = LIGNES[string.lower(texte(nom) or "")]
		if ligne and not oui(entete) and nombre(rang) then
			local x = metier(m, ligne)
			x.nom, x.rang, x.max = texte(nom), nombre(rang), nombre(max) or x.max
		end
	end
end

local function lireRecharges()
	local m = maFiche()
	if not m then return end
	local t, jeu, rech = now(), sur(GetTime) or 0, {}
	for _, x in pairs(m.metiers) do
		for _, id in ipairs(x.ids or {}) do
			local debut, duree
			if C_Spell and C_Spell.GetSpellCooldown then
				local c = sur(C_Spell.GetSpellCooldown, id)
				if type(c) == "table" then debut, duree = nombre(c.startTime), nombre(c.duration) end
			elseif GetSpellCooldown then
				local a, b = sur(GetSpellCooldown, id)
				debut, duree = nombre(a), nombre(b)
			end
			if debut and duree and debut > 0 and duree > 60 then
				local reste = debut + duree - jeu
				if reste > 0 then rech[id] = math.floor(t + reste) end
			end
		end
	end
	m.recharges = rech
end

-- Liste des membres de la guilde : lue sur place, jamais envoyée. Sert à oublier ceux qui sont partis.
local dernierRoster, guildeNoms, rosterComplet = 0, {}, nil
local function lireRoster()
	if not enGuilde() or now() - dernierRoster < 60 then return end
	local n = nombre(sur(GetNumGuildMembers)) or 0
	if n <= 0 then return end
	local noms, liste, rangs = {}, {}, {}
	for i = 1, n do
		local brut, rangNom, rangIdx = sur(GetGuildRosterInfo, i)
		local nom = court(texte(brut))
		if nom then noms[nom] = true; liste[#liste + 1] = nom; guildeNoms[nom] = true end
		if nombre(rangIdx) and texte(rangNom) then rangs[rangIdx] = texte(rangNom) end
	end
	-- liste incomplète (membres hors ligne absents) : on ne retire personne
	local nous = moi()
	if #liste < n or not nous or not noms[nous] then return end
	dernierRoster, rosterComplet = now(), noms
	local d = db()
	d.guilde = texte((sur(GetGuildInfo, "player"))) or d.guilde
	d.roster, d.rosterMaj, d.rangs = liste, now(), rangs
	for nom in pairs(d.membres) do
		if not noms[nom] then d.membres[nom] = nil end
	end
end

---------------------------------------------------------------- fenêtre de métier

local ouvert, attente, lus, aRefaire = false, false, {}, false
local planifierEnvoi

local function lireFenetre()
	local T = C_TradeSkillUI
	if type(T) ~= "table" then return end
	if oui(sur(T.IsDataSourceChanging)) or sur(T.IsTradeSkillReady) == false then return end
	-- jamais le métier de quelqu'un d'autre
	if oui(sur(T.IsTradeSkillLinked)) or oui(sur(T.IsTradeSkillGuild)) or oui(sur(T.IsTradeSkillGuildMember)) or oui(sur(T.IsNPCCrafting)) then return end
	local info = sur(T.GetBaseProfessionInfo)
	if type(info) ~= "table" then return end
	local ligne = nombre(info.parentProfessionID)
	if not ligne or ligne <= 0 then ligne = nombre(info.professionID) end
	if not ligne or ligne <= 0 or lus[ligne] then return end
	local liste = sur(T.GetAllRecipeIDs)
	if type(liste) ~= "table" or #liste == 0 then liste = sur(T.GetFilteredRecipeIDs) end
	if type(liste) ~= "table" or #liste == 0 then return end
	lus[ligne] = true
	local m = maFiche()
	if not m then return end
	local x = metier(m, ligne)
	x.nom = texte(info.parentProfessionName) or texte(info.professionName) or x.nom
	x.rang = nombre(info.skillLevel) or x.rang
	x.max = nombre(info.maxSkillLevel) or x.max
	local vues, neuves = {}, 0
	for _, id in ipairs(x.ids) do vues[id] = true end
	for i = 1, math.min(#liste, MAX_RECETTES) do
		local id = nombre(liste[i])
		local r = id and sur(T.GetRecipeInfo, id)
		if type(r) == "table" and oui(r.learned) and not vues[id] and #x.ids < MAX_RECETTES then
			vues[id] = true
			x.ids[#x.ids + 1] = id
			neuves = neuves + 1
		end
	end
	m.maj = now()
	lireRecharges()
	planifierEnvoi(8, neuves > 0)
end

local function planifierFenetre()
	if oui(sur(InCombatLockdown)) then aRefaire = true; return end
	if attente then return end
	attente = true
	C_Timer.After(1, function()
		attente = false
		if ouvert and not oui(sur(InCombatLockdown)) then pcall(lireFenetre) end
	end)
end

---------------------------------------------------------------- envoi

local file, dernierEnvoi, envoiPrevu, suite, enCours = {}, 0, nil, 0, false

-- à toute la guilde, ou en privé à un seul membre (bouche-à-oreille)
local function envoyerBrut(msg, cible)
	if not enGuilde() then return end
	local canal = cible and "WHISPER" or "GUILD"
	if C_ChatInfo and C_ChatInfo.SendAddonMessage then
		sur(C_ChatInfo.SendAddonMessage, PREFIXE, msg, canal, cible)
	elseif SendAddonMessage then
		sur(SendAddonMessage, PREFIXE, msg, canal, cible)
	end
end

local function viderFile()
	local it = table.remove(file, 1)
	if it then
		envoyerBrut(it.m, it.cible)
		C_Timer.After(PAUSE, viderFile)
	else
		enCours = false
	end
end
local function lancerFile()
	if not enCours and #file > 0 then enCours = true; viderFile() end
end
local function ajouter(msg, cible) file[#file + 1] = { m = msg, cible = cible } end

local function serialiser(nom, m, version)
	local parts = {}
	for ligne, x in pairs(m.metiers or {}) do
		local ids = {}
		for _, id in ipairs(x.ids or {}) do ids[#ids + 1] = b36(id) end
		parts[#parts + 1] = b36(ligne) .. ":" .. (x.rang or 0) .. ":" .. (x.max or 0) .. ":" .. table.concat(ids, ".")
	end
	local rech, t = {}, now()
	for id, fin in pairs(m.recharges or {}) do
		if fin > t then rech[#rech + 1] = b36(id) .. ":" .. b36(fin) end
	end
	return table.concat({ PROTOCOLE, nom, m.classe or "", "", b36(m.maj or t), table.concat(parts, "/"), table.concat(rech, ","), version or "" }, ";")
end

-- découpe sans couper une lettre accentuée en deux
local function morceaux(s)
	local t, i = {}, 1
	while i <= #s do
		local j = math.min(i + TAILLE - 1, #s)
		while j < #s and j > i do
			local b = s:byte(j + 1)
			if b < 128 or b >= 192 then break end
			j = j - 1
		end
		t[#t + 1] = s:sub(i, j)
		i = j + 1
	end
	return t
end

local function envoyerMorceaux(genre, payload, cible)
	local p = morceaux(payload)
	suite = (suite % 1295) + 1
	for i, x in ipairs(p) do ajouter(genre .. b36(suite) .. ":" .. i .. ":" .. #p .. ":" .. x, cible) end
	lancerFile()
end

local function envoyerFiche()
	envoiPrevu = nil
	local m, nom = maFiche()
	if not m or enPause() or not enGuilde() then return end
	lireRangs()
	lireRecharges()
	if compter(m.metiers) == 0 then return end
	envoyerMorceaux("D", serialiser(nom, m, VERSION))
	dernierEnvoi = now()
	db().envoi = dernierEnvoi
end

planifierEnvoi = function(delai, force)
	if not force and now() - dernierEnvoi < 90 then return end
	local quand = now() + delai
	if envoiPrevu and envoiPrevu <= quand then return end
	envoiPrevu = quand
	C_Timer.After(delai, function()
		if envoiPrevu and now() >= envoiPrevu - 1 then envoyerFiche() end
	end)
end

-- Bouche-à-oreille : à un membre qui arrive, la liste « qui j'ai, de quand » ; il demande ce qui lui manque, on le lui envoie en privé
local resumes, envoyees, demandes = {}, {}, {}

local function envoyerResume(cible)
	local k = court(cible)
	if enPause() or not k or (resumes[k] and now() - resumes[k] < 600) then return end
	resumes[k] = now()
	local L = {}
	for nom, m in pairs(db().membres) do
		if nom ~= k and type(m) == "table" and m.maj and compter(m.metiers) > 0 then L[#L + 1] = nom .. ":" .. b36(m.maj) end
	end
	if #L > 0 then envoyerMorceaux("S", table.concat(L, ","), cible) end
end

local function envoyerFichesA(noms, cible)
	local d, k, n = db(), court(cible), 0
	if enPause() or not k then return end
	for _, nom in ipairs(noms) do
		local m, cle = d.membres[nom], k .. "#" .. nom
		if n < 40 and type(m) == "table" and compter(m.metiers) > 0 and not (envoyees[cle] and now() - envoyees[cle] < 600) then
			envoyees[cle] = now()
			n = n + 1
			envoyerMorceaux("R", serialiser(nom, m, nom == moi() and VERSION or m.version), cible)
		end
	end
end

---------------------------------------------------------------- réception

local recus = {}

local function estMembre(nom) return nom and (guildeNoms[nom] or db().membres[nom] ~= nil) end

-- relaye : la fiche d'un autre membre, transmise par celui qui l'a reçue
local function lireFiche(payload, qui, relaye)
	local c = split(payload, ";")
	if c[1] ~= PROTOCOLE then return end
	local nom = court(c[2])
	if not nom or nom == moi() then return end
	if relaye then
		if rosterComplet and not rosterComplet[nom] then return end
		qui = nom
	elseif nom ~= qui then
		return
	end
	local d = db()
	if not d.membres[qui] and compter(d.membres) >= MAX_MEMBRES then return end
	local f = { classe = texte(c[3]), maj = d36(c[5]), vu = not relaye and now() or nil, metiers = {}, recharges = {}, version = texte(c[8]) }
	verifierVersion(f.version)
	for _, bloc in ipairs(split(c[6] or "", "/")) do
		local l, rang, max, ids = bloc:match("^(%w+):(%d+):(%d+):(.*)$")
		local ligne = d36(l)
		if ligne then
			local x = { rang = tonumber(rang), max = tonumber(max), ids = {} }
			for v in string.gmatch(ids or "", "[^%.]+") do
				local id = d36(v)
				if id and #x.ids < MAX_RECETTES then x.ids[#x.ids + 1] = id end
			end
			f.metiers[ligne] = x
		end
	end
	for v in string.gmatch(c[7] or "", "[^,]+") do
		local id, t = v:match("^(%w+):(%w+)$")
		if d36(id) and d36(t) then f.recharges[d36(id)] = d36(t) end
	end
	local ancien = d.membres[qui]
	local plusNeuve = type(ancien) ~= "table" or (f.maj or 0) > (ancien.maj or 0) or (not relaye and (f.maj or 0) == (ancien.maj or 0))
	if plusNeuve then
		if relaye and type(ancien) == "table" then f.vu = ancien.vu end
		d.membres[qui] = f
	elseif not relaye then
		ancien.vu = f.vu
	end
end

local function lireResume(payload, cible)
	local veux = {}
	for e in string.gmatch(payload, "[^,]+") do
		local nom, maj = e:match("^(.+):(%w+)$")
		maj = d36(maj)
		if nom and maj and nom ~= moi() and (not rosterComplet or rosterComplet[nom]) then
			local m = db().membres[nom]
			if (type(m) ~= "table" or (m.maj or 0) < maj) and not (demandes[nom] and now() - demandes[nom] < 120) then
				demandes[nom] = now()
				veux[#veux + 1] = nom
			end
		end
	end
	local ligne = ""
	for _, nom in ipairs(veux) do
		if #ligne + #nom > 230 then ajouter("W:" .. ligne, cible); ligne = "" end
		ligne = ligne == "" and nom or (ligne .. "," .. nom)
	end
	if ligne ~= "" then ajouter("W:" .. ligne, cible) end
	lancerFile()
end

local function recevoir(prefixe, msg, canal, expediteur)
	if prefixe ~= PREFIXE or type(msg) ~= "string" or (canal ~= "GUILD" and canal ~= "WHISPER") then return end
	local qui = court(expediteur)
	if not qui or qui == moi() then return end
	-- en privé, seulement un membre de la guilde
	if canal == "WHISPER" and not estMembre(qui) then return end
	if msg == "X" then db().membres[qui] = nil; return end
	if msg == "Q" or msg:sub(1, 2) == "Q:" then
		verifierVersion(texte(msg:sub(3)))
		if not enPause() then
			planifierEnvoi(math.random(3, 25))
			C_Timer.After(math.random(5, 30), function() envoyerResume(expediteur) end)
		end
		return
	end
	if msg:sub(1, 2) == "W:" then
		if canal == "WHISPER" then envoyerFichesA(split(msg:sub(3), ","), expediteur) end
		return
	end
	local genre, s, i, n, x = msg:match("^([DSR])(%w+):(%d+):(%d+):(.*)$")
	i, n = tonumber(i), tonumber(n)
	if not genre or not i or not n or n < 1 or n > 60 or i > n then return end
	if genre ~= "D" and canal ~= "WHISPER" then return end
	local cle = qui .. "#" .. genre .. s
	local r = recus[cle]
	if not r then r = { n = n, parts = {}, recu = 0, quand = now() }; recus[cle] = r end
	if not r.parts[i] then r.parts[i] = x; r.recu = r.recu + 1 end
	if r.recu >= r.n then
		recus[cle] = nil
		local payload = table.concat(r.parts)
		if genre == "D" then pcall(lireFiche, payload, qui, false)
		elseif genre == "R" then pcall(lireFiche, payload, qui, true)
		else pcall(lireResume, payload, expediteur) end
	end
	for k, v in pairs(recus) do
		if now() - v.quand > 120 then recus[k] = nil end
	end
end

---------------------------------------------------------------- recherche

local function nomSort(id)
	return (C_Spell and sur(C_Spell.GetSpellName, id)) or texte((sur(GetSpellInfo, id)))
end
local ACCENTS = { ["é"] = "e", ["è"] = "e", ["ê"] = "e", ["ë"] = "e", ["à"] = "a", ["â"] = "a", ["î"] = "i", ["ï"] = "i", ["ô"] = "o", ["û"] = "u", ["ù"] = "u", ["ç"] = "c", ["É"] = "e", ["’"] = "'" }
local function plat(s)
	s = string.lower(s or "")
	for a, b in pairs(ACCENTS) do s = s:gsub(a, b) end
	return s
end

local function chercher(mot)
	local q = plat(mot)
	if q == "" then dire("/lbf qui <recette>, par exemple /lbf qui révélation"); return end
	local trouves, ordre = {}, {}
	for nom, m in pairs(db().membres) do
		for _, x in pairs(type(m) == "table" and m.metiers or {}) do
			for _, id in ipairs(x.ids or {}) do
				local n = nomSort(id)
				if n and string.find(plat(n), q, 1, true) then
					if not trouves[n] then trouves[n] = {}; ordre[#ordre + 1] = n end
					trouves[n][#trouves[n] + 1] = nom .. (x.rang and (" (" .. x.rang .. ")") or "")
				end
			end
		end
	end
	if #ordre == 0 then dire("personne ne connaît « " .. mot .. " »."); return end
	table.sort(ordre)
	for k = 1, math.min(#ordre, 8) do dire(VERT .. ordre[k] .. "|r : " .. table.concat(trouves[ordre[k]], ", ")) end
	if #ordre > 8 then dire(string.format("et %d autres, précise le nom.", #ordre - 8)) end
end

local function compte()
	local n = 0
	for _, m in pairs(db().membres) do
		if type(m) == "table" and compter(m.metiers) > 0 then n = n + 1 end
	end
	return n
end

local function mesMetiers()
	local m, L = maFiche(), {}
	for _, x in pairs(m and m.metiers or {}) do L[#L + 1] = string.format("%s %s", x.nom or "?", x.rang or "?") end
	table.sort(L)
	return L
end

local function depuis(t)
	if not t or t <= 0 then return "pas encore" end
	local s = now() - t
	if s < 60 then return "à l'instant" end
	if s < 3600 then return string.format("il y a %d min", math.floor(s / 60)) end
	if s < 86400 then return string.format("il y a %d h", math.floor(s / 3600)) end
	return string.format("il y a %d j", math.floor(s / 86400))
end

local function pause()
	db().prive = true
	for k in pairs(file) do file[k] = nil end
	envoyerBrut("X")
	dire("pause. Plus rien ne part, et ta fiche est effacée chez les membres connectés. /lbf reprendre pour relancer.")
	if majBouton then majBouton() end
end

local function reprendre()
	db().prive = false
	planifierEnvoi(2, true)
	dire("le partage reprend.")
	if majBouton then majBouton() end
end

local function envoyerMaintenant()
	if enPause() then dire("tu es en pause, fais /lbf reprendre d'abord."); return end
	planifierEnvoi(1, true)
	dire("envoi en cours.")
end

local function statut()
	dire(string.format("v%s, partage %s, %d membre(s) avec leurs métiers dans ton carnet.", VERSION, enPause() and "en pause" or "actif", compte()))
	local m = maFiche()
	if m then
		local L = {}
		for _, x in pairs(m.metiers) do L[#L + 1] = string.format("%s %s (%d recettes)", x.nom or "?", x.rang or "?", #(x.ids or {})) end
		dire("tes métiers : " .. (#L > 0 and table.concat(L, ", ") or "rien encore, ouvre une fois chacun de tes métiers."))
	end
	dire("partagé avec la guilde : nom, classe, métiers, recettes, recharges. Rien d'autre.")
	dire("/lbf qui <recette>, /lbf envoyer, /lbf pause, /lbf reprendre, /lbf bouton")
end

---------------------------------------------------------------- bouton de la mini-carte

local ICONE = "Interface\\Icons\\Trade_BlackSmithing"
local bouton

local function bulle(tt)
	tt:AddDoubleLine("Métiers LBF", "Version " .. VERSION, 1, 0.82, 0, 0.62, 0.62, 0.62)
	local nv = nouvelleVersion()
	if nv then
		tt:AddLine("Nouvelle version disponible : " .. nv, 1, 0.5, 0)
		tt:AddLine("À télécharger sur le site de la guilde, rubrique « Addons ».", 1, 1, 1, true)
	end
	if enPause() then tt:AddLine("Partage en pause", 1, 0.3, 0.3) else tt:AddLine("Partage actif", 0.2, 1, 0.2) end
	tt:AddLine(" ")
	tt:AddDoubleLine("Dernier envoi", enCours and "en cours…" or depuis(db().envoi), 1, 0.82, 0, 1, 1, 1)
	tt:AddDoubleLine("Membres connus", tostring(compte()), 1, 0.82, 0, 1, 1, 1)
	local L = mesMetiers()
	tt:AddDoubleLine("Tes métiers", #L > 0 and table.concat(L, ", ") or "ouvre leur fenêtre", 1, 0.82, 0, 1, 1, 1)
	tt:AddLine(" ")
	tt:AddLine("Clic : le détail", 0.7, 0.7, 0.7)
	tt:AddLine("Clic droit : " .. (enPause() and "reprendre le partage" or "mettre en pause"), 0.7, 0.7, 0.7)
	tt:AddLine("Maj + clic : renvoyer tes métiers", 0.7, 0.7, 0.7)
end

local function clic(souris)
	if souris == "RightButton" then
		if enPause() then reprendre() else pause() end
	elseif IsShiftKeyDown and IsShiftKeyDown() then
		envoyerMaintenant()
	else
		statut()
	end
end

majBouton = function()
	if not bouton then return end
	local ic = bouton.icon
	if ic and ic.SetDesaturated then ic:SetDesaturated(enPause()) end
	if not bouton.lbfMaj then
		local b = bouton:CreateTexture(nil, "OVERLAY", nil, 7)
		b:SetTexture("Interface\\GossipFrame\\AvailableQuestIcon")
		b:SetSize(14, 14)
		b:SetPoint("TOPRIGHT", bouton, "TOPRIGHT", 1, 1)
		bouton.lbfMaj = b
	end
	bouton.lbfMaj:SetShown(nouvelleVersion() ~= nil)
end

local function reglages()
	local d = db()
	if type(d.icone) ~= "table" then d.icone = { hide = false } end
	return d.icone
end

local function placer(b)
	local a = math.rad(reglages().angle or 225)
	b:ClearAllPoints()
	b:SetPoint("CENTER", Minimap, "CENTER", math.cos(a) * 80, math.sin(a) * 80)
end

-- LibDBIcon si un autre addon l'a chargée (les sacs à boutons la reconnaissent), sinon un bouton simple
local function creerBouton()
	local r = reglages()
	local LDB = LibStub and LibStub("LibDataBroker-1.1", true)
	local Icone = LibStub and LibStub("LibDBIcon-1.0", true)
	if LDB and Icone then
		local obj = LDB:GetDataObjectByName("MetierLBF") or LDB:NewDataObject("MetierLBF", {
			type = "launcher", label = "Métiers LBF", text = "Métiers LBF", icon = ICONE,
			OnClick = function(_, souris) clic(souris) end,
			OnTooltipShow = function(tt) bulle(tt) end,
		})
		if obj and not Icone:IsRegistered("MetierLBF") then Icone:Register("MetierLBF", obj, r) end
		bouton = Icone:GetMinimapButton("MetierLBF")
	elseif Minimap then
		local b = CreateFrame("Button", "LibDBIcon10_MetierLBF", Minimap)
		b:SetSize(31, 31)
		b:SetFrameStrata("MEDIUM")
		b:SetFrameLevel(8)
		b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
		b:RegisterForDrag("LeftButton")
		b:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
		local fond = b:CreateTexture(nil, "BACKGROUND")
		fond:SetTexture("Interface\\Minimap\\UI-Minimap-Background")
		fond:SetSize(24, 24)
		fond:SetPoint("CENTER")
		local ic = b:CreateTexture(nil, "ARTWORK")
		ic:SetTexture(ICONE)
		ic:SetSize(18, 18)
		ic:SetPoint("CENTER")
		ic:SetTexCoord(0.07, 0.93, 0.07, 0.93)
		b.icon = ic
		local bord = b:CreateTexture(nil, "OVERLAY")
		bord:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
		bord:SetSize(50, 50)
		bord:SetPoint("TOPLEFT")
		b:SetScript("OnClick", function(_, souris) clic(souris) end)
		b:SetScript("OnDragStart", function(self)
			self:SetScript("OnUpdate", function()
				local mx, my = Minimap:GetCenter()
				local px, py = GetCursorPosition()
				local s = Minimap:GetEffectiveScale()
				reglages().angle = math.deg(math.atan2(py / s - my, px / s - mx))
				placer(self)
			end)
		end)
		b:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)
		b:SetScript("OnEnter", function(self)
			GameTooltip:SetOwner(self, "ANCHOR_LEFT")
			bulle(GameTooltip)
			GameTooltip:Show()
		end)
		b:SetScript("OnLeave", function() GameTooltip:Hide() end)
		placer(b)
		if r.hide then b:Hide() end
		bouton = b
	end
	if AddonCompartmentFrame and AddonCompartmentFrame.RegisterAddon then
		pcall(AddonCompartmentFrame.RegisterAddon, AddonCompartmentFrame, { text = "Métiers LBF", icon = ICONE, notCheckable = true,
			func = function(_, _, _, _, souris) clic(souris) end })
	end
	majBouton()
end

local function basculerBouton()
	local r = reglages()
	r.hide = not r.hide
	local Icone = LibStub and LibStub("LibDBIcon-1.0", true)
	if Icone and Icone:IsRegistered("MetierLBF") then
		if r.hide then Icone:Hide("MetierLBF") else Icone:Show("MetierLBF") end
	elseif bouton then
		bouton:SetShown(not r.hide)
	end
	dire(r.hide and "bouton caché (/lbf bouton pour le remettre)." or "bouton affiché.")
end

---------------------------------------------------------------- /lbf

SLASH_METIERLBF1 = "/lbf"
SlashCmdList.METIERLBF = function(arg)
	arg = (arg or ""):gsub("^%s+", ""):gsub("%s+$", "")
	local cmd, reste = arg:match("^(%S+)%s*(.*)$")
	cmd = string.lower(cmd or "")
	if cmd == "pause" then pause()
	elseif cmd == "reprendre" then reprendre()
	elseif cmd == "envoyer" then envoyerMaintenant()
	elseif cmd == "qui" then chercher(reste)
	elseif cmd == "bouton" then basculerBouton()
	else statut() end
end

---------------------------------------------------------------- évènements

local f = CreateFrame("Frame")
local connecte = false
for _, ev in ipairs({ "PLAYER_LOGIN", "PLAYER_ENTERING_WORLD", "TRADE_SKILL_SHOW", "TRADE_SKILL_LIST_UPDATE", "TRADE_SKILL_CLOSE",
	"NEW_RECIPE_LEARNED", "CHAT_MSG_ADDON", "PLAYER_REGEN_ENABLED", "SKILL_LINES_CHANGED", "GUILD_ROSTER_UPDATE" }) do
	pcall(f.RegisterEvent, f, ev)
end

f:SetScript("OnEvent", function(_, ev, a1, a2, a3, a4)
	if ev == "CHAT_MSG_ADDON" then
		recevoir(a1, a2, a3, a4)
	elseif ev == "PLAYER_LOGIN" then
		pcall(creerBouton)
		if C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix then
			sur(C_ChatInfo.RegisterAddonMessagePrefix, PREFIXE)
		elseif RegisterAddonMessagePrefix then
			sur(RegisterAddonMessagePrefix, PREFIXE)
		end
	elseif ev == "PLAYER_ENTERING_WORLD" then
		if connecte then return end
		connecte = true
		if not db().accueil then
			db().accueil = true
			C_Timer.After(8, function()
				dire("partage avec ta guilde le nom de ton perso, sa classe, tes métiers, tes recettes et tes recharges. Rien d'autre.")
				dire("/lbf pour le détail, /lbf pause pour arrêter.")
			end)
		end
		C_Timer.After(5, function()
			local nous = moi()
			if enGuilde() then pcall(lireRangs) elseif nous then db().membres[nous] = nil end
			for nom, m in pairs(db().membres) do
				if nom ~= nous and (type(m) ~= "table" or compter(m.metiers) == 0) then db().membres[nom] = nil end
			end
		end)
		if not nouvelleVersion() then db().derniere = nil end
		C_Timer.After(12, annoncerMaj)
		C_Timer.After(10, function()
			if C_GuildInfo and C_GuildInfo.GuildRoster then sur(C_GuildInfo.GuildRoster) elseif GuildRoster then sur(GuildRoster) end
		end)
		C_Timer.After(15, function() ajouter("Q:" .. VERSION); lancerFile() end)
		planifierEnvoi(math.random(25, 45), true)
	elseif ev == "GUILD_ROSTER_UPDATE" then
		pcall(lireRoster)
	elseif ev == "TRADE_SKILL_SHOW" then
		ouvert, lus = true, {}
		planifierFenetre()
	elseif ev == "TRADE_SKILL_LIST_UPDATE" then
		if ouvert then planifierFenetre() end
	elseif ev == "TRADE_SKILL_CLOSE" then
		ouvert = false
	elseif ev == "NEW_RECIPE_LEARNED" then
		local id, T = nombre(a1), C_TradeSkillUI
		if not id or type(T) ~= "table" or not T.GetProfessionInfoByRecipeID then return end
		local info = sur(T.GetProfessionInfoByRecipeID, id)
		if type(info) ~= "table" then return end
		local ligne = nombre(info.parentProfessionID)
		if not ligne or ligne <= 0 then ligne = nombre(info.professionID) end
		local m = maFiche()
		if not ligne or ligne <= 0 or not m then return end
		local x = metier(m, ligne)
		for _, v in ipairs(x.ids) do if v == id then return end end
		x.ids[#x.ids + 1] = id
		m.maj = now()
		planifierEnvoi(10, true)
	elseif ev == "PLAYER_REGEN_ENABLED" then
		if aRefaire then
			aRefaire = false
			if ouvert then planifierFenetre() end
		end
	elseif ev == "SKILL_LINES_CHANGED" then
		pcall(lireRangs)
	end
end)
